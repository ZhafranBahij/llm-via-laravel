# Prism: Laravel-LLM

## Installation

It’s not special, you just follow this tutorial.

[https://prism.echolabs.dev/getting-started/installation.html](https://prism.echolabs.dev/getting-started/installation.html)

### image

![image.png](image.png)

![image.png](image%201.png)

## Config

If you want to “try”, I recommend using Groq because you don’t need Credit Card to access it.

[https://groq.com/](https://groq.com/)

![image.png](image%202.png)

```
GROQ_API_KEY="insert_your_groq_api_key"
```

## How to Use

Follow this instruction

[https://prism.echolabs.dev/core-concepts/text-generation.html](https://prism.echolabs.dev/core-concepts/text-generation.html)

Example

![image.png](image%203.png)

### image

![image.png](image%204.png)

## Using to Identify Image

![image.png](image%205.png)

So, can LLM identify this picture, especially identify the girl with white hair.

Prompt:

```
Descriptions about the girl in this picture
```

- groq
    
    Model:
    
    llama-3.2-11b-vision-preview
    
    ![image.png](image%206.png)
    
    If I use normal model (without support image preview) a.k.a llama3-8b-8192, the result will like this.
    
    ![image.png](image%207.png)
    
- xai
    
    model:
    
    grok-2-vision-1212
    
    ![image.png](image%208.png)
    

## Creating Via Command

Create command

```bash
php artisan make:command AskAi
```

Signature for execute the command. You can replace ‘ai:ask’ to anything what you want.

```php
protected $signature = 'ai:ask';
```

- The Code
    
    ```php
    /**
     * Execute the console command.
     */
    public function handle()
    {
        /**
         * Example usage of the Prism library to generate a response from Groq in simple way
         */
    
        // Ask user for input
        $question = textarea('Something in your mind?');
    
        $answer = Prism::text()
            ->using(Provider::Groq, 'llama3-8b-8192')
            // ->withSystemPrompt('You are an expert historian who explains concepts simply.') // You can remove this line if you don't want to use system prompt
            ->withPrompt($question)
            ->generate()
            ->text;
    
        // Output the answer
        $this->info($answer);
    }
    ```
    

Excute command

```bash
php artisan ask:ai
```

![image.png](image%209.png)

## Identify Image Via Command

Creating command first

After that, you can use this code

- Code
    
    ```php
    /**
     * Execute the console command.
     */
    public function handle()
    {
        /**
         * Example usage for image messages
         * ! For now I recommend using via URL
         */
    
        $image = textarea('Enter the URL of the image to review:');
    
        // From a local file
        // $message = new UserMessage(
        //     "What's in this image?",
        //     [Image::fromPath('img/assc.jpg')]
        // );
    
        // From a URL
        $message = new UserMessage(
            'Descriptions about something in this picture',
            [Image::fromUrl($image)]
        );
    
        // From a Base64
        // $image = base64_encode(file_get_contents('img/assc.jpg'));
    
        // $message = new UserMessage(
        //     'Analyze this diagram:',
        //     [Image::fromBase64($image, 'jpeg')]
        // );
    
        $answer = Prism::text()
                    ->using(Provider::Groq, env('GROQ_MODEL_FOR_IMAGE'))
                    ->withMessages([$message])
                    ->generate()
                    ->text;
    
        $this->info($answer);
    }
    ```
    

![image.png](image%2010.png)

## Creating Chat Via Command

- Code
    
    ```php
    /**
     * Array of messages
     */
    private $messages = [];
    
    /**
     * Execute the console command.
     */
    public function handle()
    {
        /**
         * Example usage of the Prism library to generate a response from Groq in simple way
         */
    
        while (true) {
            // Ask user for input
            $question = textarea('Something in your mind?');
    
            // Add user message to the array of messages
            $this->messages[] = new UserMessage($question);
    
            $answer = Prism::text()
                ->using(Provider::Groq, env('GROQ_MODEL'))
                // ->withSystemPrompt('You are an expert historian who explains concepts simply.') // You can remove this line if you don't want to use system prompt
                ->withMessages($this->messages)
                ->generate()
                ->text;
    
            // Output the answer
            $this->info($answer);
    
            // Add assistant message to the array of messages
            $this->messages[] = new AssistantMessage($answer);
        }
    }
    ```
    

![image.png](image%2011.png)

## Review Image Via Command

### From Local

```php
$message = new UserMessage(
    "What's in this image?",
    [Image::fromPath('public/img/assc.jpg')]
);

$answer = Prism::text()
            ->using(Provider::Groq, env('GROQ_MODEL_FOR_IMAGE'))
            ->withMessages([$message])
            ->generate()
            ->text;

$this->info($answer);
```

- Image
    
    ![assc.jpg](assc.jpg)
    

![image.png](image%2012.png)

### From Base64

```php
// From a Base64
$image = base64_encode(file_get_contents('public/img/assc.jpg'));

$message = new UserMessage(
    'Analyze this image:',
    [Image::fromBase64($image, 'jpeg')]
);

$answer = Prism::text()
            ->using(Provider::Groq, env('GROQ_MODEL_FOR_IMAGE'))
            ->withMessages([$message])
            ->generate()
            ->text;

$this->info($answer);
```

- Image
    
    ![assc.jpg](assc.jpg)
    

![image.png](image%2013.png)

### From URL

```php
// From a URL
$message = new UserMessage(
    'Descriptions about something in this picture',
    [Image::fromUrl($image)]
);

$answer = Prism::text()
            ->using(Provider::Groq, env('GROQ_MODEL_FOR_IMAGE'))
            ->withMessages([$message])
            ->generate()
            ->text;

$this->info($answer);
```

- Image
    
    ![image.png](image%2014.png)
    

![image.png](image%2015.png)

## Using Tools Via Command

Step by step

You can copy paste this step and set api_key to your serpapi api key

[https://prism.echolabs.dev/core-concepts/tools-function-calling.html#complex-tool-implementation](https://prism.echolabs.dev/core-concepts/tools-function-calling.html#complex-tool-implementation)

### Code

```php
<?php

namespace App\Tools;

use EchoLabs\Prism\Tool;
use Illuminate\Support\Facades\Http;

class SearchTool extends Tool
{
    public function __construct()
    {
        $this
            ->as('search')
            ->for('useful when you need to search something')
            ->withStringParameter('query', 'Detail search query')
            ->using($this);
    }

    public function __invoke(string $query): string
    {
        // dd('test');
        $response = Http::get('https://serpapi.com/search', [
            'engine' => 'google',
            'q' => $query,
            'google_domain' => 'google.com',
            'gl' => 'us',
            'hl' => 'en',
            'api_key' => env('SERPAPI_API_KEY')
        ]);

        $results = collect($response->json('organic_results'));

        $results = $results->map(function ($result) {
            return [
                'title' => $result['title'],
                'link' => $result['link'],
                'snippet' => $result['snippet'],
            ];
        })->take(4);

        return view('prompts.search-tool-results', [
            'results' => $results
            ])
            ->render();

    }
}

```

```
<links>
    @foreach ($results as $result)
        <link>
            <title>{{ $result['title'] }}</title>
            <url>{{ $result['link'] }}</url>
            <snippet>{{ $result['snippet'] }}</snippet>
        </link>
    @endforeach
</links>

ALWAYS CITE SOURCES AT THE END OF YOUR RESPONSE

<example-sources>

</example-sources>

```

```php
private $messages = [];

/**
 * Execute the console command.
 */
public function handle()
{
    /**
     * Example usage of the Prism library to generate a response from Groq in simple way
     */

    while (true) {
        // Ask user for input
        $question = textarea('Something in your mind?');

        // Add user message to the array of messages
        $this->messages[] = new UserMessage($question);

        $answer = Prism::text()
                        ->withTools([
                            new SearchTool(),
                        ])
                        ->withMaxSteps(5)
                        ->withMessages($this->messages)
                        ->using(Provider::Groq, env('GROQ_MODEL'))
                        ->generate()
                        ->text;

        // Output the answer
        $this->info($answer);

        // Add assistant message to the array of messages
        $this->messages[] = new AssistantMessage($answer);
    }

}
```

![image.png](image%2016.png)

### Why Using Search Tools Like Serpapi?

Serpapi can help you to give AI new knowledge based on search engine.

Example

If I use serpapi

![image.png](image%2016.png)

Without serpapi

![image.png](image%2017.png)

So, who is true?

Well, nobody is true, but with serpapi will close to the truth. 

![image.png](image%2018.png)

---

## Example Using Another LLM

This is example from my experiences. 

I want to choose LLM if this LLM don’t need Credit Card. Honestly, I don’t want to fill credit card input for development. 

### OpenAI

[https://openai.com/api/](https://openai.com/api/)

![image.png](image%2019.png)

- Why didn’t use OpenAI?
    
    ![image.png](image%2020.png)
    
    You need Credit card :”
    
    ![image.png](image%2021.png)
    

### Antropic

[https://console.anthropic.com/dashboard](https://console.anthropic.com/dashboard)

- Why?
    
    ![image.png](image%2022.png)
    
    You need buy credits.
    
    ![image.png](image%2023.png)
    

### Ollama

![image.png](image%2024.png)

- Why I don’t use it?
    
    Maybe I’ll use it later if I can’t found any LLM that I like
    

### Mistral AI

![image.png](image%2025.png)

- Why I didn’t use it?
    
    ![image.png](image%2026.png)
    
    Add your payment information.
    
    Maybe. I’m don’t login for now. But, I thought I’ll skip it.
    

### Groq

[https://groq.com/](https://groq.com/)

![image.png](image%2027.png)

- Why use it?
    
    You don’t need payment and credit card. Honestly, for development only, I’m little care about rate limit. 
    

### XAI

[https://x.ai/](https://x.ai/)

![image.png](image%2028.png)

- Why I don’t use it?
    
    ![image.png](image%2029.png)
    
    You have limited credits. Maybe, I’ll use it later if I want.
    
    Note: I use it in image preview
    
- Example
    
    ![image.png](image%2030.png)
    

## Learning Via Nuno Maduro

https://www.youtube.com/watch?v=4WzS91_TVz8

### Install Prism

Just follow this step

[https://prism.echolabs.dev/getting-started/installation.html](https://prism.echolabs.dev/getting-started/installation.html)

### Create New Command

Create new command via terminal

```bash
php artisan make:command ChatCommand
```

Config ChatCommand

```php
  /**
   * The name and signature of the console command.
   *
   * @var string
   */
  protected $signature = 'chat';

  /**
   * The console command description.
   *
   * @var string
   */
  protected $description = 'Chat using Prism';
```

Setting .env

```
GROQ_API_KEY="your_groq_api_key"
GROQ_MODEL="llama3-8b-8192"
```

### Using Chat Command

Try prism

```php
    /**
     * Execute the console command.
     */
    public function handle()
    {
        $message = textarea('Message');

        $prism = $this->prismFactory();

        $answer = $prism->withPrompt($message)
                        ->generate()
                        ->text;

        dd($answer);
    }

    protected function prismFactory(): Generator
    {
        return Prism::text()
                ->using(Provider::Groq, env('GROQ_MODEL'));
    }
```

Execute via terminal

```bash
php artisan chat
```

Example

![image.png](image%2031.png)

### Using Box

Don’t forget to import Colors and DrawBoxes before use it

```php
    use Colors;
    use DrawsBoxes;
    
    public function handle(){
	    //...
	    $this->box('Response', wordwrap($answer->text, 40), color: 'magenta');
    }
```

Example

![image.png](image%2032.png)

![image.png](image%2033.png)

### Multi chat

```php
    protected Collection $messages;

    public function __construct() {
        parent::__construct();

        $this->messages = collect();
    }

    
    /**
     * Execute the console command.
     */
    public function handle()
    {
        $prism = $this->prismFactory();

        $this->messages = collect();

        while (true) {
            $this->chat($prism);
        }
    }

    protected function prismFactory(): Generator
    {
        return Prism::text()
                ->using(Provider::Groq, env('GROQ_MODEL'));
    }

    protected function chat(Generator $prism): void
    {
        $message = textarea('Message');

        $this->messages->push(new UserMessage($message));

        $answer = $prism
                        ->withMessages($this->messages->toArray())
                        ->generate();

        $this->messages = $this->messages->merge($answer->responseMessages);

        $this->box('Response', wordwrap($answer->text, 40), color: 'magenta');
    }
```

![image.png](image%2034.png)

### Using Tools or SERP

[https://serpapi.com/](https://serpapi.com/)

![image.png](image%2035.png)

Create .env

```
SERPAPI_API_KEY="03251f5408650b2d48ab79b2a2e7495f5b7dbd4e3379e3f52619ffb61047e4d4"
```

Create Search Tool Class

```php
<?php

namespace App\Tools;

use EchoLabs\Prism\Tool;
use Illuminate\Support\Facades\Http;

class SearchTool extends Tool
{
    public function __construct()
    {
        $this
            ->as('search')
            ->for('useful when you need to search something')
            ->withStringParameter('query', 'Detail search query')
            ->using($this);
    }

    public function __invoke(string $query): string
    {
        // dd('test');
        $response = Http::get('https://serpapi.com/search', [
            'engine' => 'google',
            'q' => $query,
            'google_domain' => 'google.com',
            'gl' => 'us',
            'hl' => 'en',
            'api_key' => env('SERPAPI_API_KEY')
        ]);

        // dd($response);

        $results = collect($response->json('organic_results'));

        // dd($results);

        $results = $results->map(function ($result) {
            return [
                'title' => $result['title'],
                'link' => $result['link'],
                'snippet' => $result['snippet'],
            ];
        })->take(4);

        // dd($results);

        return view('prompts.search-tool-results', [
            'results' => $results
            ])
            ->render();

    }

}

```

Add new things in ChatCommand

```php
protected function prismFactory(): Generator
{
    return Prism::text()
            ->withTools([
                new SearchTool(),
            ])
            ->withMaxSteps(5)
            ->using(Provider::Groq, env('GROQ_MODEL'));
}
```

Example

![image.png](image%2036.png)